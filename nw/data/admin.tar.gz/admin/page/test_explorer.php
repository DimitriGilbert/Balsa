<?php

include_once('../../init.php');
include_once($path.'admin/fonction/explorer.php');
$ex=new explorer();
$ex->serv_xml();

?>
